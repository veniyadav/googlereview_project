require("dotenv").config();
const express = require("express");
const { google } = require("googleapis");
const axios = require("axios");
const fs = require("fs");

const app = express();
const PORT =3000;


const oAuth2Client = new google.auth.OAuth2(
  "472330366874-efetdreipeh0hfcj3mpnijt7017mmu4g.apps.googleusercontent.com",
  "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",
  "http://localhost:3000/oauth/callback"
);

app.get("/auth", (req, res) => {
  const url = oAuth2Client.generateAuthUrl({
    access_type: "offline",
    scope: ["https://www.googleapis.com/auth/business.manage"],
  });
  console.log("Generated URL:", url);

  res.redirect(url);
});


app.get("/oauth/callback", async (req, res) => {
  const code = req.query.code;
  try {
    const { tokens } = await oAuth2Client.getToken(code);
    oAuth2Client.setCredentials(tokens);

    // Save both access and refresh tokens
    fs.writeFileSync("token.json", JSON.stringify(tokens, null, 2));
    console.log("Tokens saved:", JSON.stringify(tokens, null, 2));

    res.send("Authentication successful! Tokens saved.");
  } catch (err) {
    console.error(err);
    res.send("Error authenticating");
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
